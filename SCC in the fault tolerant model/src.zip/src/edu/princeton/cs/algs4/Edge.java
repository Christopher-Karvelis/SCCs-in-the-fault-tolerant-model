package edu.princeton.cs.algs4;

public class Edge {

    int head;
    int tail;
    Edge(int head ,int tail){
        this.head=head;
        this.tail=tail;
    }
}
